# pygobotics

Python API allowing remote control of simulated robots in the [Gobotics](https://github.com/LD2Studio/gobotics) application.

# LICENSE

This software is distributed under the MIT License.
